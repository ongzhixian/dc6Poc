﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WordAddIn1
{
    public partial class DataLinkUserControl1 : UserControl
    {
        public DataLinkUserControl1()
        {
            InitializeComponent();
        }
    }
}
