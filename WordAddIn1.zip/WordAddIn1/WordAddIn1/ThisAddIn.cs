﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using Word = Microsoft.Office.Interop.Word;
using Office = Microsoft.Office.Core;
using Microsoft.Office.Tools.Word;

namespace WordAddIn1
{
    public partial class ThisAddIn
    {
        private Microsoft.Office.Tools.Word.Controls.Button button = null;
        private RichTextContentControl richTextControl = null;

        private Northwind1DataSet northwind1DataSet;
        private Northwind1DataSetTableAdapters.CustomersTableAdapter customerTableAdapter;
        private System.Windows.Forms.BindingSource customerBindingSource;
        private Microsoft.Office.Tools.Word.RichTextContentControl customerContentControl;
        private Microsoft.Office.Tools.Word.Controls.Button button1;
        private Microsoft.Office.Tools.Word.Controls.Button button2;


        private DataLinkUserControl1 myUserControl1;
        private Microsoft.Office.Tools.CustomTaskPane myCustomTaskPane;

        //private TaskPaneControl taskPaneControl1;
        //private Microsoft.Office.Tools.CustomTaskPane taskPaneValue;


        private void ThisAddIn_Startup(object sender, System.EventArgs e)
        {
            this.Application.DocumentBeforeSave +=
                new Word.ApplicationEvents4_DocumentBeforeSaveEventHandler(Application_DocumentBeforeSave);

            this.Application.DocumentOpen += Application_DocumentOpen;

            this.northwind1DataSet = new Northwind1DataSet();
            this.customerTableAdapter = new Northwind1DataSetTableAdapters.CustomersTableAdapter();
            this.customerTableAdapter.Fill(this.northwind1DataSet.Customers);
            this.customerBindingSource = new System.Windows.Forms.BindingSource();

            myUserControl1 = new DataLinkUserControl1();
            myCustomTaskPane = this.CustomTaskPanes.Add(myUserControl1, "My Task Pane");
            myCustomTaskPane.Visible = true;
            myCustomTaskPane.VisibleChanged += MyCustomTaskPane_VisibleChanged;
        }

        private void MyCustomTaskPane_VisibleChanged(object sender, EventArgs e)
        {
            Globals.Ribbons.Ribbon1.toggleButton1.Checked = myCustomTaskPane.Visible;
            
        }

        public Microsoft.Office.Tools.CustomTaskPane TaskPane
        {
            get
            {
                return myCustomTaskPane;
            }
        }

        private void Application_DocumentOpen(Word.Document Doc)
        {
            Word.Document currentDocument = this.Application.ActiveDocument;

            Document extendedDocument = Globals.Factory.GetVstoObject(currentDocument);

            extendedDocument.Paragraphs[1].Range.InsertParagraphBefore();
            extendedDocument.Paragraphs[1].Range.InsertParagraphBefore();
            extendedDocument.Paragraphs[1].Range.Text =
                "The companies listed in the AdventureWorksLT database:   \n";
            extendedDocument.Paragraphs[2].Range.Text = "  ";

            Word.Range range1 = extendedDocument.Paragraphs[2].Range.Characters.First;
            Word.Range range2 = extendedDocument.Paragraphs[2].Range.Characters.Last;
            Word.Range range3 = extendedDocument.Paragraphs[1].Range.Characters.Last;


            this.button1 = extendedDocument.Controls.AddButton(range1, 60, 15, "1");
            this.button1.Text = "Previous";
            this.button2 = extendedDocument.Controls.AddButton(range2, 60, 15, "2");
            this.button2.Text = "Next";

            this.customerContentControl = extendedDocument.Controls.AddRichTextContentControl(
                range3, "richTextContentControl1");

            this.customerBindingSource.DataSource = this.northwind1DataSet.Customers;

            this.customerContentControl.DataBindings.Add("Text", this.customerBindingSource,
                "Company", true, this.customerContentControl.DataBindings.DefaultDataSourceUpdateMode);

            //extendedDocument.Controls.where
            //Microsoft.Office.Tools.Word.Document.
            //IEnumerable<ContentControl> contentControls = extendedDocument.ContentControls.GetEnumerator()
            //IEnumerable<object> contentControlList1 = extendedDocument.ContentControls.Cast<object>();
            //IEnumerable<ContentControl> contentControlList2 = extendedDocument.ContentControls.OfType<ContentControl>();
            //IEnumerable<ContentControl> contentControlList3 = extendedDocument.ContentControls.Cast<ContentControl>();
            //int cc1Count = contentControlList1.Count();
            //int cc2Count = contentControlList2.Count();
            //int cc3Count = contentControlList3.Count();

            //Microsoft.Office.Tools.Word.RichTextContentControl customerContentControl;
            //Microsoft.Office.Tools.Word.PlainTextContentControl x;

            int count = 0;
            try
            {
                Word.ContentControls foundControls = extendedDocument.SelectContentControlsByTag("city");
                //var sx = foundControls.Count;

                foreach (Word.ContentControl ctrl in foundControls)
                {
                    System.Data.DataRowView dv = (System.Data.DataRowView)this.customerBindingSource.Current;
                    ctrl.Range.Text = dv.Row["City"].ToString();

                    PlainTextContentControl ptcc = extendedDocument.Controls.AddPlainTextContentControl(
                        ctrl, "contentControlCity");

                    ptcc.DataBindings.Add("Text", this.customerBindingSource,
                        "City", true, this.customerContentControl.DataBindings.DefaultDataSourceUpdateMode);

                    //if (ctrl.Type == Microsoft.Office.Interop.Word.WdContentControlType.wdContentControlRichText)
                    //{
                    //    count++;
                    //    Microsoft.Office.Tools.Word.RichTextContentControl tempControl =
                    //        extendedDocument.Controls.AddRichTextContentControl(ctrl,
                    //        "VSTORichTextControl" + count.ToString());
                    //    //richTextControls.Add(tempControl);
                    //}

                    //if (ctrl.Type == Microsoft.Office.Interop.Word.WdContentControlType.wdContentControlText)
                    //{
                    //    count++;
                    //    Microsoft.Office.Tools.Word.PlainTextContentControl tempControl =
                    //        extendedDocument.Controls.AddPlainTextContentControl(ctrl,
                    //        "vstoPlainTextControl" + count.ToString());
                    //    //richTextControls.Add(tempControl);
                    //}
                }

                foundControls = extendedDocument.SelectContentControlsByTag("customer_list");
                // foundControls are RepeatingSectionItem; each instance representing a "row"

                int rowCount = foundControls.Count;

                int dataIndex = 0;
                int dataRow = 0;

                var data = new List<KeyValuePair<string, string>>();
                data.Add(new KeyValuePair<string, string>("row 1a", "row 1b"));
                data.Add(new KeyValuePair<string, string>("row 2a", "row 2b"));
                data.Add(new KeyValuePair<string, string>("row 3a", "row 3b"));


                foreach (Word.ContentControl ctrl in foundControls)
                {
                    var sectionItemsCount = ctrl.RepeatingSectionItems.Count; // number of "rows" in section

                    while (sectionItemsCount < data.Count)
                    {
                        ctrl.RepeatingSectionItems[1].InsertItemBefore();
                        sectionItemsCount = ctrl.RepeatingSectionItems.Count;
                    }

                    var innerControlsCount = ctrl.Range.ContentControls.Count;

                    for (dataRow = 1; dataRow <= sectionItemsCount; dataRow++)
                    {
                        Word.RepeatingSectionItem row = ctrl.RepeatingSectionItems[dataRow];

                        int rowControlCount = row.Range.ContentControls.Count;

                        foreach (Word.ContentControl innerCtrl in row.Range.ContentControls)
                        {
                            // Skip Section container
                            if (innerCtrl.Type == Word.WdContentControlType.wdContentControlRepeatingSection)
                                continue;

                            if (innerCtrl.Tag == "first_name")
                                innerCtrl.Range.Text = data[dataRow - 1].Key;
                            if (innerCtrl.Tag == "last_name")
                                innerCtrl.Range.Text = data[dataRow - 1].Value;
                        }

                    }

                    //foreach (Word.ContentControl innerCtrl in ctrl.Range.ContentControls)
                    //{
                    //    // We can identify via `innerCtrl.Title` or `innerCtrl.Tag`
                        
                    //    // Skip Section container
                    //    if (innerCtrl.Type == Word.WdContentControlType.wdContentControlRepeatingSection)
                    //        continue;

                    //    if ((dataIndex % 2) == 0)
                    //    {
                    //        innerCtrl.Range.Text = data[dataRow].Key;
                    //    }
                    //    else
                    //    {
                    //        innerCtrl.Range.Text = data[dataRow].Value;
                    //        dataRow++;
                    //    }
                    //    dataIndex++;
                    //}

                    // -------------------------------
                    //Word.ContentControl rSCC = extendedDocument.ContentControls.Add(
                    //    Word.WdContentControlType.wdContentControlRepeatingSection, ctrl.Range);
                    
                    // Add another row
                    //var item = rSCC.RepeatingSectionItems[1].InsertItemAfter();
                    

                    //PlainTextContentControl ptcc = extendedDocument.Controls.(
                    //    ctrl, "contentControlCity");
                }

            }
            catch (Exception ex)
            {
                throw;
            }


            this.button1.Click += new EventHandler(button1_Click);
            this.button2.Click += new EventHandler(button2_Click);
        }

        private void ThisAddIn_Shutdown(object sender, System.EventArgs e)
        {
        }

        void SetContentControlTextByTag(string tag, string value)
        {
            Word.Document currentDocument = this.Application.ActiveDocument;

            Document extendedDocument = Globals.Factory.GetVstoObject(currentDocument);

            foreach (Word.ContentControl ctrl in extendedDocument.SelectContentControlsByTag(tag))
                ctrl.Range.Text = value;
        }

        void rebind()
        {
            System.Data.DataRowView dv = (System.Data.DataRowView)this.customerBindingSource.Current;

            SetContentControlTextByTag("city", dv.Row["City"].ToString());
        }


        void Application_DocumentBeforeSave(Word.Document Doc, ref bool SaveAsUI, ref bool Cancel)
        {
            Doc.Paragraphs[1].Range.InsertParagraphBefore();
            Doc.Paragraphs[1].Range.Text = "This text was added by using code.";

            bool isExtended = Globals.Factory.HasVstoObject(Doc);


            if (isExtended)
            {
                Microsoft.Office.Tools.Word.Document vstoDocument = Globals.Factory.GetVstoObject(Doc);

                if (vstoDocument.Controls.Contains(button))
                {
                    vstoDocument.Controls.Remove(button);
                    Globals.Ribbons.Ribbon1.addButtonCheckBox.Checked = false;
                }
            }
        }

        internal void ToggleButtonOnDocument()
        {
            Document vstoDocument = Globals.Factory.GetVstoObject(this.Application.ActiveDocument);

            string name = "MyButton";

            if (Globals.Ribbons.Ribbon1.addButtonCheckBox.Checked)
            {
                Word.Selection selection = this.Application.Selection;
                if (selection != null && selection.Range != null)
                {
                    button = vstoDocument.Controls.AddButton(
                        selection.Range, 100, 30, name);
                }
            }
            else
            {
                vstoDocument.Controls.Remove(name);
            }
        }

        internal void ToggleRichTextControlOnDocument()
        {

            Document vstoDocument = Globals.Factory.GetVstoObject(this.Application.ActiveDocument);


            string name = "MyRichTextBoxControl";

            if (Globals.Ribbons.Ribbon1.addRichTextCheckBox.Checked)
            {
                Word.Selection selection = this.Application.Selection;
                if (selection != null && selection.Range != null)
                {
                    richTextControl = vstoDocument.Controls.AddRichTextContentControl(
                        selection.Range, name);
                }
            }
            else
            {
                vstoDocument.Controls.Remove(name);
            }
        }

        void button1_Click(object sender, EventArgs e)
        {
            this.customerBindingSource.MovePrevious();
            //rebind();
        }

        void button2_Click(object sender, EventArgs e)
        {
            this.customerBindingSource.MoveNext();
            //rebind();
        }

        // Untested; keeping for reference
        //public static List<ContentControl> GetAllContentControls(Document wordDocument)
        //{
        //    var ccList = new List<ContentControl>();
        //    foreach (Range range in wordDocument.StoryRanges)
        //    {
        //        var rangeStory = range;
        //        do
        //        {
        //            try
        //            {
        //                foreach (ContentControl cc in rangeStory.ContentControls)
        //                {
        //                    ccList.Add(cc);
        //                }
        //            }
        //            catch (COMException)
        //            {
        //            }
        //            rangeStory = rangeStory.NextStoryRange;
        //        } while (rangeStory != null);
        //    }
        //    return ccList;
        //}

        #region VSTO generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InternalStartup()
        {
            this.Startup += new System.EventHandler(ThisAddIn_Startup);
            this.Shutdown += new System.EventHandler(ThisAddIn_Shutdown);
        }

        #endregion
    }
}
